#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
if [ -x "./gradlew" ]; then
  ./gradlew test assembleDebug
else
  echo "Gradle wrapper missing. Open in Android Studio or generate wrapper with installed Gradle first." >&2
  exit 2
fi
cd ..
zip -r VoiceAgentAndroid-source.zip VoiceAgentAndroid -x '*/.gradle/*' '*/build/*' '*/local.properties'
echo "Created VoiceAgentAndroid-source.zip"
