# Build the APK using only an Android phone

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

1. On your phone, sign in to GitHub and create a **private** repository.
2. Upload the extracted project files to the repository, keeping the `.github/workflows/build-apk.yml` path intact. If the mobile website hides file-upload options, enable **Desktop site** in your browser.
3. Open the repository's **Actions** tab and select **Build VoiceAgentAndroid APK**.
4. Tap **Run workflow** if prompted, or wait for the workflow to run after the files are committed.
5. When the run finishes successfully, open that run and download the `VoiceAgentAndroid-debug-apk` artifact.
6. Extract the downloaded artifact ZIP, tap the `.apk` file, and allow your browser/file manager to install unknown apps if Android asks.

Important: this workflow is a build attempt, not a guarantee that this source compiles. The source project has not been compiled or device-tested. If the workflow fails, open the run and share the first relevant error lines. Do not upload API keys or passwords to the repository.
