package com.example.voiceagent

import org.junit.Assert.assertTrue
import org.junit.Test

class CommandRoutingTest {
    @Test fun starterProjectHasTestSource() {
        // Activity routing requires Android instrumentation; this smoke test checks test setup.
        assertTrue("starter".contains("start"))
    }
}
