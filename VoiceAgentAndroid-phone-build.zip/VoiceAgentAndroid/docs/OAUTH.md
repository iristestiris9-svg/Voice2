# OAuth/API integration plan (not yet wired)

This project deliberately does not include real credentials or a fake working OAuth flow.

## Recommended flow
1. Choose a provider and register an Android/public client.
2. Use OAuth 2.0 Authorization Code + PKCE through the system browser and a vetted library such as AppAuth for Android.
3. Register exact redirect URIs and request the minimum scopes.
4. Validate `state`; validate OIDC `nonce` when using OpenID Connect.
5. Keep client IDs (which are public identifiers) in environment-specific configuration. Never embed a confidential client secret in the APK.
6. Store refresh/access tokens only when necessary, using Keystore-backed encryption; clear tokens on logout and provide revocation.
7. For APIs requiring confidential credentials, call your own backend; keep secrets server-side.
8. Use documented provider endpoints only. Do not scrape endpoints or attempt to bypass authentication.

## Required configuration before implementation
- Provider/issuer URL
- Client ID
- Exact redirect URI
- Scopes
- API base URL and required data handling policy
- Backend URL, if confidential credentials are needed

Until these are configured, the API agent returns a placeholder message and performs no network calls.
