# Agent responsibilities

- Voice Authenticator: this starter uses Android BiometricPrompt, not a voiceprint model.
- Core Orchestrator: simple allowlisted command routing in `MainActivity.executeCommand`.
- Device Controller: safe settings intents, browser launch, dialer/messaging UI, volume guidance.
- Security Agent: fail-closed UI gate and redacted Android log hook; production policy engine remains to be implemented.
- Cybersecurity Agent: explanatory placeholder only; no scanning or exploitation tools.
- Personal Assistant: demo note persistence; reminders/calendar integration not implemented.
- Conversational Agent: local fallback response only; no LLM provider configured.
- API Integration Agent: OAuth plan and placeholder; no credentials or provider connected.
- ZIP Compiler: project is delivered as source archive; CI/tested release packaging remains to be configured.
